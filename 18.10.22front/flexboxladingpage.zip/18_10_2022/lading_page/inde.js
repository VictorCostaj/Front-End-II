let modal = document.getElementById("modal");

document.getElementById("clica").addEventListener("click", (e) => {
  e.preventDefault();
  //modal.style.visibility = "visible";
  modal.showModal();
});
